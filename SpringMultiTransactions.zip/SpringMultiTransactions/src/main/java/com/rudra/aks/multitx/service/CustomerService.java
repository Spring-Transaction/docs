package com.rudra.aks.multitx.service;

import com.rudra.aks.multitx.domain.CustomerBO;

public interface CustomerService {

	Integer save(CustomerBO customer);

}
