package com.rudra.aks.xa.service;

import com.rudra.aks.xa.domain.CustomerBO;

public interface CustomerService {

	Integer save(CustomerBO customer);

}
