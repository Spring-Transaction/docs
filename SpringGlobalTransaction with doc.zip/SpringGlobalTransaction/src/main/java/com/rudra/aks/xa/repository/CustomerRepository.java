package com.rudra.aks.xa.repository;

/*import org.springframework.data.repository.CrudRepository;

import com.rudra.aks.xa.domain.CustomerBO;

public interface CustomerRepository extends CrudRepository<CustomerBO, Integer>{

}
*/